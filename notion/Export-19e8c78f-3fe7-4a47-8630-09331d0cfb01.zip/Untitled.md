# Песни слов

[Будьте первыми (Роберт Рождественский)](Untitled/Untitled.md)

[Ты прекрасная, нежная женщина (Асадов)](Untitled/Untitled%201.md)

[Сонет 102 (Шекспир)](Untitled/102.md)

[Тысячный человек (Киплинг)](Untitled/Untitled%202.md)

[Больному (Саша Чёрный)](Untitled/Untitled%203.md)

[Истина (Валерий Марченко)](Untitled/Untitled%204.md)

[Заповедь / Письмо к сыну (Киплинг)](Untitled/Untitled%205.md)

[Третье письмо к Тейми (Касьян)](Untitled/Untitled%206.md)

[Попытка ревности (Цветаева)](Untitled/Untitled%207.md)

[Гафт. Я и ты...](Untitled/Untitled%208.md)

[](Untitled/Untitled%209.md)