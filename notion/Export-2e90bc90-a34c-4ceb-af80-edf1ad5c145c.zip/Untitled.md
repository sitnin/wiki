# Спектакль

**Концепт спектакля**

Рассказчик на своей свадьбе. За долю секунды между вопросом «согласны?» и ответами -- пролетает вся предыдущая жизнь и принимается финальное решение «Да».

Это происходит у обоих влюбленных.

Начало и конец -- церемония и этот момент объявления супругами. Все остальное -- ситуации из сначала личных, а потом и совместных историй. Разные: смешные, страшные, грустные, поучительные и тд. Именно эти истории привели к этому моменту и к этим ответам.

Финальные титры можно заебенить под https://music.yandex.ru/album/4003191/track/32819492

Еще в саундтрек: https://music.yandex.ru/album/3562299/track/29603887

https://music.yandex.ru/album/6424854/track/47350721

https://music.yandex.ru/album/4792728/track/37749916

https://music.yandex.ru/album/644864/track/5885121

https://music.yandex.ru/album/7113863/track/51143747

https://music.yandex.ru/album/1055143/track/9896282

https://music.yandex.ru/album/357470/track/3400674

https://music.yandex.ru/album/3897965/track/31876064

https://music.yandex.ru/album/5809510/track/43617577

https://music.yandex.ru/album/67981/track/96210