# Growth

[Проблемы в метриках](Growth/Untitled.md)

[https://venngage.com/blog/marketing-plan/](https://venngage.com/blog/marketing-plan/)

[https://venngage.com/blog/growth-strategy/](https://venngage.com/blog/growth-strategy/)

[https://redbranchmedia.com/blog/no-one-sets-goals-like-marketer/](https://redbranchmedia.com/blog/no-one-sets-goals-like-marketer/)

[https://foundr.com/marketing-strategy/](https://foundr.com/marketing-strategy/)

![Growth/kvlopcdk.bmp](Growth/kvlopcdk.bmp)

[https://venngage.com/blog/user-persona-examples/](https://venngage.com/blog/user-persona-examples/)

[https://venngage.com/features/persona-guide](https://venngage.com/features/persona-guide)

[https://www.formstack.com/blog/2018/optimize-customer-journey/](https://www.formstack.com/blog/2018/optimize-customer-journey/)

![Growth/Growth-Experiment-Template.png](Growth/Growth-Experiment-Template.png)

![Growth/o5aywiru.bmp](Growth/o5aywiru.bmp)

[https://insights.newscred.com/how-to-create-an-integrated-marketing-campaign/](https://insights.newscred.com/how-to-create-an-integrated-marketing-campaign/)

[productvaluepropositionandmessagingtemplateplussalescard-160709162615.pdf](Growth/productvaluepropositionandmessagingtemplateplussalescard-160709162615.pdf)

[https://kapost.com/b/product-marketing-and-customer-knowledge/](https://kapost.com/b/product-marketing-and-customer-knowledge/)

[https://blog.hubspot.com/service/customer-journey-map](https://blog.hubspot.com/service/customer-journey-map)

![Growth/Presentcustomerjourneymap.png](Growth/Presentcustomerjourneymap.png)

![Growth/Futurecustomerjourneymap.png](Growth/Futurecustomerjourneymap.png)

[https://conversionxl.com/blog/customer-journey-maps/](https://conversionxl.com/blog/customer-journey-maps/)

![Growth/RailEurope_CXMap_FINAL.001.png](Growth/RailEurope_CXMap_FINAL.001.png)

[Многомерная шкала перфекционизма Хьюитта-Флетта](Growth/Untitled%201.md)