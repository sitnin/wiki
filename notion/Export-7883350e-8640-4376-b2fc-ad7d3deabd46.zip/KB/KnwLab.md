# KnwLab

[http://cdb.neurop.org/](http://cdb.neurop.org/)

[http://cdb.neurop.org:8080/npe](http://cdb.neurop.org:8080/npe)

[https://task.neurop.org/projects/po_neurobracelet_err/wiki/Сервер_моделей_(NpEngine)#Коды-ошибок-выполнения-команд](https://task.neurop.org/projects/po_neurobracelet_err/wiki/%D0%A1%D0%B5%D1%80%D0%B2%D0%B5%D1%80_%D0%BC%D0%BE%D0%B4%D0%B5%D0%BB%D0%B5%D0%B9_(NpEngine)#%D0%9A%D0%BE%D0%B4%D1%8B-%D0%BE%D1%88%D0%B8%D0%B1%D0%BE%D0%BA-%D0%B2%D1%8B%D0%BF%D0%BE%D0%BB%D0%BD%D0%B5%D0%BD%D0%B8%D1%8F-%D0%BA%D0%BE%D0%BC%D0%B0%D0%BD%D0%B4)

[https://docs.google.com/document/d/1wCmEvkL8f0szH9q9scOG8QFjU1FMR58DEbX7HuwP6Vs/edit#](https://docs.google.com/document/d/1wCmEvkL8f0szH9q9scOG8QFjU1FMR58DEbX7HuwP6Vs/edit#)

{
"id": 72,
"name": "Grisha",
"enabled": true,
"secret": "Fentynbabrfwb9Uhbib",
"redirectUri": "[https://knw.local/authcb](https://knw.local/authcb)",
"clientData": "{\"AllowedScopes\": [\"api\"], \"AllowedGrantTypes\": [\"implicit\"], \"AccessTokenLifetime\": 99000, \"AllowAccessTokensViaBrowser\": true}",
"comment": "Grisha tests",
"modified": "2019-07-26T14:56:34.2778094+00:00"
}

[front.neurop.org](http://front.neurop.org/) 188.120.235.223:51535

??? 62.109.5.19

[cdb.neurop.org](http://cdb.neurop.org/) 62.109.4.83:61535
[cdb-backup.neurop.org](http://cdb-backup.neurop.org/) 82.146.60.107:61535
[doc.knwlab.com](http://doc.knwlab.com/) 188.120.235.223:51535
[text.conceptino.org](http://text.conceptino.org/) 37.230.114.47:22

front - это хозяйство Фароса. Там паспорт и таймбраузер
cdb - вотчина Маслова. Там платформа
cdb-backup - тоже Маслов. реплика платформы
[doc.knwlab.com](http://doc.knwlab.com/) - чисто наш, им никто больше не управляет. Там лежат [developers.neurop.org](http://developers.neurop.org/) и всё, что с этим связано: git и т.п.
[text.conceptino.org](http://text.conceptino.org/) - Концептино, графовая система. там что-то сломано на уровне авторизации