# Лучшие из когда-либо написанных заголовков

How To Raise Your Child’s IQ Before It Is Even Born.

How Much Are You Losing To Deadbeats Right Now?

SELL YOUR PRODUCT ON NATIONAL TELEVISION FOR A PERCENTAGE OF PROFIT

He Became Twice The Man At Half The Weight

The Secret Of Being Wealthy

PHONE WIZARD

The Child Who Won The Hearts Of All

One Place-Setting Free For Every Three You Buy!

Do You Make These Mistakes In Job Interviews?

HOW TO WRITE A GOOD ADVERTISEMENT

Doctors Prove 2 Out Of 3 Women Can Have More Beautiful Skin In 14 Days

Life In The Fast Lane

THE CRIMES WE COMMIT AGAINST OUR STOMACHS

A Breakthrough Idea For Those Who Want To Act In The Movies

Which Of These 5 Skin Problems Do You Have?

Test Your Ability To Ever Grow Up

Here Is A Way To Become Tight, Lean, Attractive And Remarkably Healthy In Just

45 Minutes Three Times A Week.

How Do You Grow $1,000 Worth of Food In A Garden This Small?

Why People On The Queensland Are Healthier, Less Overweight, Stay Young

Longer, Live Longer Than People Of Any Other State In Australia

STOP DREAMING AND START MAKING MONEY

Free Giant Cookie

How To Get Out Of The Rat Race And Into The Chips

Wanted: Your Old Shredder. Get a Minimum $700 Trade In On Our New Models

Throw Away Your Oars!

This Is Marie Antoinette – Riding To Her Death

The Chinese Secrets Of Weight Control

THINK AND GROW RICH

Who Else Wants To Make Big Money In Electronics

Three Powerful Reasons You Should Come To My Seminar

New Rubber Stamp Business Pays Beginners Up To $20.70 An Hour!

If Your Bathroom Isn’t Ready In 8 Days I’ll Give You $100 Cash For Every Day We Go Over Time

Who’s Making A Bundle?

YOU CAN LAUGH AT MONEY WORRIES IF YOU FOLLOW THIS SIMPLE PLAN

Watch Your Weight And Inches Disappear

They Laughed When I Sat Down At The Piano – But When I Started To Play!

$80,000 In Prizes! Help Us Find The Name For These New Kitchens

Vita-Mix Makes Juice 12 Times Faster Than Other Juicers – And 400% More Nutritious

Who Else Wants A Screen Star Figure?

How Your Horoscope Can Bring You Wealth, Love, Success And Happiness

IMAGINE ME...HOLDING AN AUDIENCE SPELLBOUND FOR 30 MINUTES!

Why Are We Giving You These $18.50 Delicious Macadamia Nut Chocolates – For FREE?

THE AMAZING SECRETS OF THE HOTTEST INVESTMENT OF THE LAST 5 YEARS!

Have A House You’ll Be Proud Of...With ColourMakers Range Of 362 Tiles And

New Easy-To-Apply House Paint

The Amazing Money-Making Power Of Pac-Man And His Friends!

Important News For People Who Swore They Would Never Try Another Reducing Product

How To Pay Zero Taxes!

A Wonderful Two Years’ Trip At Full Pay – But Only Man With Imagination Can Take It

THE $112,000 HOUSEWIFE

Your TV Fixed In 4 Days Or It’s FREE

Confessions Of A Disbarred Lawyer

“You Kill That Story – Or I’ll Run You Out Of The State!”

Smart Car Owners: Save Up To 87% Off Retail Prices On Your Spare Parts

THE SECRET OF PERFECT PUTTING

How to Become Debt-Free And Stay That Way – Forever

Where You Can Go In A Good Used Car

How To Write A Business Letter

Mobile Money Maker

Today...Add $10,000 To Your Estate – For The Price Of A New Hat

Gold Coast Lawyer Discovers How To Make Money At Home With The Help Of The Federal Government

Right And Wrong Farming Methods – And Little Pointers That Will Increase Your Profits

Do You Sincerely Want To Be Rich?

World Poker Champ Sells Secrets For $9.95

THOUSANDS NOW PLAY WHO NEVER THOUGHT THEY COULD

Do You Do Any Of These Ten Embarrassing Things?

How To Get $373,500 Out Of A $30,000 House

At Last, Someone Has Unlocked The Secret Of Getting People To Fall In Love With You!

IF YOU READ MUSIC YOU’LL LOVE OUR MAGAZINE

Brighten Your Dark Rooms In Less Than 1 Hour

How To Form Your Corporation Without A Lawyer For Under $50.00

Are You Ready To Use Self-Hypnotism To Make Life Give You What You Want?

“I Had Been Overweight For 10 Years, So... My Friends Could Hardly Believe Their

Eyes When They Saw Me Lose 56 Pounds In Only 6 Weeks!”

Do You Make These Mistakes In English?

WHAT’S YOUR BEST CHANCE TO MAKE MONEY IN REAL ESTATE

TODAY? THE ANSWER BELOW MAY SURPRISE YOU.

You Don’t Have To Die To Collect On Your Insurance Policy

Some Straight Talk About Vitamins And Your Sex Life

How You Can Make Money With The Arabs

THE AMAZING GRAFTON “WRINKLE ERASER” DISCOVERED BY A TOP ORIENTAL CHEMIST

47 REASONS WHY IT WOULD HAVE PAID YOU TO ANSWER YOUR AD A FEW MONTHS AGO

Buy No Desk...Until You’ve Seen This Sensation Of The Business Show

New “Energy Pill” Tested By The R.A.A.F. With Amazing Results

The Amazing “Face-Life-In-A-Jar” Used By Hollywood Stars Who Don’t Want Plastic Surgery

HERE ARE 87 SURPRISE WAYS TO GET MONEY FROM PARLIAMENT HOUSE

Released At Last – 143 Perfectly Legal Ways To Get A Cheque Out Of Uncle Sam!

The Machine That Peels Off Kilograms While You Sit Back And Enjoy It

How To Wake Up The Financial Genius Inside You

How You Can Eat More And Weight Less

Remember When You Could Have picked Up A Good Piece Of Real Estate For A

Song – And Didn’t?

Is The Life Of A Child Worth $1 To You?

Imagine Being Such A Great Lover Women Can See It In Your Eyes!

How Long Will You Live? Ignorance About Taking Care Of Yourself Can Be The

Mistake That Kills You In Your 50’s or 60’s ... “The Dangerous Years!”

HOW TO DISCOVER WHAT YOU ARE REALLY GOOD AT

Again She Orders...”A Chicken Said, Please”

7 Ways Long Distance Can Keep Your Head Above Water

How To Rob Race Tracks Legally

How To Avoid Having Your Car Stolen This Summer On The Gold Coast

Lawyers Reveal Legal Loopholes That Make Money

Generous Creative Businessman Wants To Find A Hot Sexy Woman With A Good Sense Of Humor

HOW TO MAKE MONEY WRITING SHORT PARAGRAPHS

Science Has Finally Counterfeited A Perfect Diamond!

WOULD YOU LIKE TO TAKE IN $140 AFTER SUPPER?

“Insider Information” – On Who’s Really Making Money – Plus Exactly How Those Businesses Operate

The Secret Of Teaching Yourself Music

HOW TO BURN OFF BODY FAT, HOUR BY HOUR!

Sunshine Coast Man Swears Under Oath That His New “Energy Pill” Does Not

Contain Cocaine Or Any Other Illegal Stimulant – “It’s A Food, Not A Drug,” Says Joe Bloggs

At Marina Mirage’s New Mexican Restaurant Your First Meal is FREE

FREE KIT TELLS HOW TO TAKE BETTER PHOTOGRAPHS

Inventors, Strike Paydirt!

It’s A Shame For YOU Not To Make Good Money – When These Men Do It So Easily

Fountain Of Youth Discovered By Little Known Civilization Over 2700 Years Ago

How To Obtain Guaranteed Credit Anywhere In Australia

Now Any Auto Repair Job Can Be “Duck Soup: For You

How To Get Rich In Reading Classified Ads

SYDNEY LAWYER REVEALS THE INSIDERS WAY TO GET EVEN

HOW TO MAKE A FORTUNE TODAY STARTING FROM SCRATCH!

How To Find Someone To Love

TO THE TRAVELING SALESMAN WHO’S SMART ENOUGH TO KNOW WHEN TO CALL IT QUITS

How To Turn $5000 Into $5,436 In Just 12 Months

To People Who Want To Write – But Can’t Get Started

161 NEW WAYS TO A MAN’S HEART – IN THIS FASCINATING BOOK FOR COOKS

Why Some People Almost Always Make Money In The Stock Market

It’s Easy To Cash In On Your Amazing Astrological Abilities

How To Make A Killing In Closeouts

How Often Do You Hear Yourself Saying, “No, I haven’t Read It; I’ve been Meaning To!”

Can You Pass This Memory Test?

TOO BUSY EARNING A LIVING TO MAKE ANY MONEY?

LOOK GREAT WITH OUR FREE STYLECUT

Brisbane Man Reveals A Shortcut To Authorship

“Send Me To Any City In Australia. Take Away My Wallet. Give Me $100.00 For

Living Expenses And In 72 Hours I’ll Buy You An Excellent Piece Of Real Estate Using None Of My Own Money.”

Attention: Home Owner, Don’t Buy Any Curtains Until You Read This

How To Give Your Children Extra Iron – These 3 Delicious Ways

Money-Saving Bargains From Australia’s Oldest Diamond Discount House

The 5 Most Costly Mistakes In Business – How Many Are You Making Right Now?

The Inside Story Of A Business That Requires So Little Of Anything, You Could Run It Out Of A Phone Booth

12 Special Tax Strategies That Are Making Doctors Rich

WHAT’S YOUR BEST CHANCE OF EARNING $50,000 A YEAR BY THE TIME YOU ARE 30?

No More Back-Breaking Garden Chores For Me – Yet Ours Is Now The Show Place

Of The Neighborhood!

MAKE ANYONE DO ANYTHING YOU MENTALLY COMMAND – WITH YOUR MIND ALONE!

DARE TO BE RICH!

Take This 1-Minute Test – Of An Amazing New Kind Of Shaving Cream

9 Good Reasons To Choose Country Curtains Quality Sun Blinds And Beat The Scorching Heat This Summer

THE MAN WITH THE “GRASSHOPPER MIND”

“...The Amazing Thing, Of Course, Is The Speed At Which This Program Works. It Is Rather Remarkable To Throw Off As Much As 4 Kilograms Of Fluid And Fat In The Very First Weekend...”

Man Who Limped With Foot Pain – Now Runs 2 Miles Every Day!

Some Straight Talk About Earning Extra Income

How To Make Money With Display Ads

IMAGINE WORKING UNTIL 4:00AM – AND LOVING EVERY MINUTE OF IT!

AMAZING NEW TITANIC COMMEMORATIVE IS MINT-PERFECT AND

EVEN BIGGER THAN A FIFTY CENT PIECE!

My Name Is Michael Trent...And I’d Like To Make A Confession!

Thousands Have This Priceless Gift – But Never Discover It!

The Last 2 Hours Are The Longest – And Those Are The 2 Hours You Save

How To Pay Less For Advertising While You Get More Orders

An Open Letter To Every Overweight Person In Melbourne

ONE TRANSACTION CAN MAKE YOU INDEPENDENT FOR THE REST OF YOUR LIFE

They Shocked Us. They Outraged Us. They Didn’t Do Anything Wrong – They Just Did It First

I’d Like To Give This To May Fellow Men – While I Am Still Able To Help

HOW TO DEVELOP A SILVER TONGUE, A GOLDEN TOUCHA ND A MIND LIKE A STEEL TRAP

How To Raise And Train Your Puppy

New Halley’s Comet “Silver Eagle” Is Totally Unique And Made Of Pure Silver!

Free 1 Month Gym Membership Worth $79 With Every Pair Of Reebok Cross-

Trainer Shoes. This Weekend Only.

WHY SOME FOODS “EXPLODE” IN YOUR STOMACH

WANT TO SAVE A BUNDLE? AN OPEN LETTER TO EVERYONE WHO DRIVES A TRUCK OR CAR MORE THAN 10,000 KILOMETERS PER YEAR

The Other Side Of The Story On Rock Hudson

A Little Mistake Cost A Farmer $3,000 A Year

How Much Is “Worker Tension” Costing Your Company?

Free Book – Tells You 12 Secrets Of Better Lawn Care

The Secret Of How Australia’s Number One Handicapper “STOLE” Over $1,000,000 From The Racetracks Last Year

HOW TO WIN FRIENDS AND INFLUENCE PEOPLE

New Diet Burns Off More Fat Than If You Ran 98 Kilometers A Week!

Make Extra Cash Writing Advertising Book Match Covers

Pregnant? The Sooner You Know, The Better.

Everywhere Women Are Raving About This Amazing New Shampoo!

WHY THESE VITAMINS CAN MAKE YOU FEEL PEPPIER

NOW LET THIS STRANGE AND POWERFUL GIFT FROM OUTER SPACE

BRING YOU INCREDIBLE GOOD LUCK – ABSOLUTELY GUARANTEED!

“Some Straight Talk About Vitamins And Your Sex Life”

Are You Closing Your Eyes To The Profit Potential In 800 Services?

Winning At The Races May Not Be Your Idea Of Fun, But...

What Everybody Ought To Know... About This Stock And Bond Business

Pierced By 421 Nails...Retains Full Air Pressure

Advice To Wives Whose Husbands Don’t Save Money – By A Wife

THE AMAZING $10.00 FAKE DIAMOND THAT WILL FOOL 9 OUT OF 10 JEWELLERS

There’s Another Woman Waiting For Every Man – And She’s Too Smart To Have

“Morning Mouth”

FREE Report – “How To Increase Your Profits In A Recession.”

Are You Too Busy Earning A Living To Make Any Money?

TESTED ADVERTISING METHODS

Local Business Swears Under Oath He Did Not Steal Any Of The Car Radios He Is

Selling So Cheap

Doctor Discovers The Cellulite Dissolver

How To Write Copy That Will Make You Rich

THE SECRET OF MAKING PEOPLE LIKE YOU

The “10 Quickest Ways” To Get More Customers

You Can’t Become Rich In Your pocket Until You Become Rich In Your Mind!

How To Beat Tension Without Pills?

If You Can Read And Write Simple English, I’ll Show You How To Make Real

Money Selling Words

Now! Own Queensland Land This Easy Way...$10 Down And $10 A Month

How To Get What The Australian Government Owes YOU!

7 Ways To Collect Your Unpaid Bills

Let Me Tell You How I Reduced For Keeps

17 STOCKS YOU SHOULD DUMP RIGHT AWAY

The Lowdown On Self-Publishing

If You Were Given $200,000 To Spend – Isn’t This The Kind Of (type of product, but not brand name) You Would Build

You Never Saw Such Letters As Harry And I Got About Our Pears

Do Your Employees Work As Slowly As They Read?

Suppose This Happened On Your Wedding Day!

How To Get A Free Supply Of An Amazing New Diet Pill That Works Like Crazy!

This Almost-Magical Lamp Lights Highway Turns Before You Make Them

A STARTLING FACT ABOUT MONEY

The Most Expensive Magazine In The World. Yet Over 40,000 Businessmen Buy It Every Month. Why?

Have You Ever Seen A Grown Man Cry?

How To Discover The Fortune Lying Hidden In Your Daily Paper

DON’T TRY THIS WITH ANY OTHER COPIER

Fatten Your Bank Account

HOW TO DISCOVER THE PRICELESS SECRET OF GOOD HEALTH AND SLASH YOUR MEDICAL BILLS IN HALF!

It’s Crazy That A High School Dropout Would Make This Much Money

Six Types of Investors – Which Group Are You In?

Here’s A Quick Way To Break Up A Cold

THE SECRET OF HAVING GOOD LUCK

How To Start From “Scratch” And Become A P.O. Box Millionaire

HOW TO GET A GRIP ON AUDIENCE ATTENTION

Adelaide Man Discovers The Secret Of How To Escape The Australian Rat Race

When Doctors “Feel Rotten” This Is What They Do

Profits That Lie Hidden In Your Farm

But What If You Could See Her Naked?

This Pen ”Burps” Before It Drinks - But Never Afterwards!

Here’s A Way To Make Money That Has Never Yet Failed

How To Push Your Resume To The Top Of The Stack

What Would You Rather Do This Evening: Watch TV Or Make Some Real Money?

Reduce Office Turnover By 100%

Want To Be A Legal Investigator?

He Was 240 Pounds Of Sweet Tooth

New Help For Not So Perfect Hair

Take Any 3 Of These Kitchen Appliances – For Only $8.95 (Values UP To $15.95)

An Educated Failure

Reduce While You Sleep

GUARANTEED TO GO THRU ICE, MUD OR SNOW – OR WE PAY THE TOW!

The Amazing Diet Secret Of A Frustrated Toowoomba Housewife

How A “Fool Stunt” Made Me A Star Salesman

How A New Kind Of Clay Improved My Complexion In 30 Minutes

TOM MCCAHILL SAYS: “THE APPLIANCE REPAIR FIELD IS SO

UNCROWDED IT’S ALMOST LONELY”

How To Flatten Your Tush

Did You Ever See A “Telegram” From Your Heart?

An Amazing Business You Can Carry In Your Pocket

The Amazing Blackjack Secret Of A Las Vegas Mystery Man!

If Your Home Doesn’t Have An Alarm He’ll Break In In Just 10 Seconds. With A Wormald Back-To-Base Alarm He Won’t Even Try!

Famed Physicist Proves That Sitting In A Pyramid Causes Unexplainable Good

Things To Happen

How To Collect From Social Security At Any Age!

The Passport To Riches

HAVE YOU EVER TAKEN A PRACTICE GOLF SWING AT A DANDELION?

How To Plan Your House To Suit Yourself

How The Experts Buy And Sell Gold And Silver

ANNOUNCING...THE NEW EDITION OF THE ENCYCLOPEDIA THAT

MAKES IT FUN TO LEARN THINGS

The Amazing “Magic Mud” Used By A Top TV Doctor Who Doesn’t Believe In Plastic Surgery!

Do You Have These Symptoms Of Nervous Exhaustion?

Little Leaks That Keep Men Poor

Are You Ever Tongue-Tied At A Party?

Don’t Envy The Plumber – Be One

How I Made A Fortune With A “Fool Idea”

My Feet Were Killing Me...Until I Discovered The Miracle In Germany

HERE’S HOW TO FIND OUT IF YOUR BANK IS ABOUT TO GO BANKRUPT!

It’s Easy To Cash In On Your Amazing Astrological Abilities

The Secret Of Making People Like You

NEED MORE MONEY?

Good News For Franchise Owners: Here’s How To Get Hundreds Of Qualified

Leads At Half The Cost

What’s Wrong With This Picture?

How Bad A Beating Are You Willing To Take To Own A New Car?

Does Uncle Sam Owe You Money You Don’t Even Know About

How To Discover The Fortune That Lies Hidden In Your Head

How To Take Out Stains...Use (product X) And Follow These Easy Directions

New Shampoo Leaves Your Hair Smoother – Easier To Manage

HOW TO OWN A $139,000 INVESTMENT HOME FROM ONLY $35 PER WEEK AND NO DEPOSIT

38 Fun, Easy Ways To Earn $500 Next Weekend

How To Do Wonders With A Little Land!

7 Steps To Freedom

Corporation Uses Magazine Articles As Marketing Key

HANDS THAT LOOK LOVELIER IN 24 HOURS – OR YOUR MONEY BACK

We’re Looking For People To Write Children’s Books

You Don’t Know Me, I Realize...But I Want You To Have This Before It’s Too Late

How To Overcome The Body Chemical That Keeps You Fat!

How Come Some People Can Walk Up To A Blackjack Table And Always Walk

Away A Winner

Moneymaking Sledgehammer

Want To Be An Airline Flight Attendant?

Why Some Foods Explode In Your Stomach

How A New Discovery Made A Plain Girl Beautiful

The Deaf Now Hear Whispers

The Ugly Truth About Your New Car

Scientists Discover Mystery Chemical That Seems To Drive Women Wild!

TO MEN WHO WANT TO QUIT WORK SOMEDAY

Who Else Wants Lighter Cake – In Half The Mixing Time?

10 Easy Ways To Meet People, Have Fun And Lose Some Weight At The Same Time

The Truth About Getting Rich

The Book On Who Owns Whom

NEW PILL FOR DIET FAILURES LETS YOU BURN OFF BODY FAT 24 HOURS A DAY!

Are You Tired Of The Treatment You’re Getting?

New Pill Gives Almost Complete Relief From Arthritis Pain!

BANKING SECRETS THAT BANKS DON’T WANT PUBLISHED

How The Way You Undress Reveals Your Personality

ALIVE WITH PLEASURE

Check The Kind Of Body You Want

How To Improve Your Memory

Desperate Woman Loses 277 Pounds With Amazing New Diet Secret!

NEW! YOUR CHILD IS THE STAR OF THIS BRAND NEW SESAME STREET STORYBOOK!

Have You Ever Said, “I Just Can’t Seem To Concentrate?”

The Amazing Diet Secret Of A Desperate Housewife

No Office – No Phones – No Hassles – Just Cold Hard Cash In The Mail!

How To Turn Stumbling Blocks Into Stepping Stones

If You Read Nothing Else – Read This

FINANCIAL COLUMNIST MAKES UNIQUE DISCOVERY

Greatest Gold Mine Of Easy “Things-To-Make” Ever Crammed Into One Big Book

The Most Comfortable Shoes You Have Ever Worn Or Your Money Back

Why (X brand) Bulbs Give You More Light This Year

THE PEOPLE WHO READ THIS BOOK WILL END UP WITH YOUR MONEY

How To Beat The Banks At Their Own Game

Often A Bridesmaid, Never A Bride

How I Made A Fortune With A “Fool Idea”

The Amazing Secret Of A Marketing Genius Who Is Afraid To Fly

Save 20 Cents On 2 Cans Of Blueberry Sauce – Limited Offer

THE LAZY MAN’S WAY TO RICHES

Greed And Gouging In The Stock Market

IF YOU CAN LICK A STAMP – YOU CAN LICK YOUR WEIGHT PROBLEM

Former Barber Earns $8,000 In 4 Months As A Real Estate Specialist

The Most Expensive Mistake Of Your Life

Call Back These Great Moments At The Opera

“LAST FRIDAY...WAS I SCARED – MY BOSS ALMOST FIRED ME!”

How To Double Your Income In Just 60 Days

Own A Business Of Your Choice Without Investing 1 Cent

“I Lost My Bulges...And Saved Money Too”

The Art Of Selling By Telephone

Where The Money Is And How To Get It

Get Out Of Debt In 90 Minutes Without Borrowing!

HOW TO GET FREE ADVERTISING AND FREE PUBLICITY

How To Get 12 Hours Out Of An 80-Hour Day

FULL TIME MINISTER FINDS PART TIME GOLDMINE!

Are You An Overeducated Underachiever?

Movie Actor Reveals Amazing New Weight-Loss Breakthrough

Lost For Words? Push The Buttons And Voila!

How To Raise Venture Capital Without Losing Equity

Are We A Nation Of Low-Brows?

At 6 For 99 Cents, You Can Indulge Your Fantasies This Month

Does Your Child Ever Embarrass You?

How To Have A Cool Quiet Bedroom. Even On Hot Summer Nights.

You Can Only Go So Far On BS

The Secret Of Sticking To Your Diet

Want To Lose Some Weight?

The Amazing Lost Money Secret Of The U.S. Government

How You Can Legally Profit From “Insider” Information On The Stock Market

THE SECRET OF BOWLING STRIKES

Can Your Child Read These Words?

How To Write A Hit Song And Sell It

Which Of These 5 Skin Troubles Would You Like To End?

WHOSE FAULT WHEN CHILDREN DISOBEY?

New Cake-Improver Gets You Compliments Galore!

For The Woman Who Is Older Than She Looks

Using A Lawyer May Be Dangerous To Your Wealth

BY THIS TIME NEXT MONTH, YOU COULD HAVE A GLOBAL DATA COMMUNICATIONS NETWORK

Have You Ever Bowled A Strike And Said, “I’ve Got It!”?

“No Time For TAFE – Took College At Home”, Says Well-Known Author

Speak Spanish Like A Diplomat

You’ll Just Love The Way This Diet Pill Works!

Great New Discovery Kills Kitchen Odors Quick! – Makes Indoor Air “Country-Fresh”

IS YOUR HOME PICTURE-POOR?

Have You A “Worry” Stock?

Are They Being Promoted Right Over Your Head?

DON’T LET ATHLETE’S FOOT “LAY YOU UP”