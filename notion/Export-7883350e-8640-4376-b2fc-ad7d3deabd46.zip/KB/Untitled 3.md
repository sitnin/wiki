# СПИН

![Untitled%203/metod_spin_prodazhi.png](Untitled%203/metod_spin_prodazhi.png)

[https://spincat.ru/theory-of-spin/metod-spin-prodazhi](https://spincat.ru/theory-of-spin/metod-spin-prodazhi#2)

[https://youtu.be/apUhQ1A2PnI](https://youtu.be/apUhQ1A2PnI)

[https://spincat.ru/practice-spin/primery-spin-prodazhi](https://spincat.ru/practice-spin/primery-spin-prodazhi)

![Untitled%203/____.png](Untitled%203/____.png)