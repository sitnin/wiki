# Sitnin.com

[DFEngine](Sitnin%20com/DFEngine.md)

[**Создание лендинга минимального продукта**](Sitnin%20com/Untitled.md)

[Комментарий на [vc.ru](http://vc.ru) по поводу акселераторов](Sitnin%20com/vc%20ru.md)