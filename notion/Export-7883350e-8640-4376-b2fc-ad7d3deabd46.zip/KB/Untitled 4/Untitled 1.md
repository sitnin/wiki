# Песни и стихи

[Иметь дочь](Untitled%201/Untitled.md)

[Там, где я хочу быть. Тот, кем я хочу быть.](Untitled%201/Untitled%201.md)

[Меня погубишь](Untitled%201/Untitled%202.md)

[Нюте на ДР](Untitled%201/Untitled%203.md)

[Олин голос. Филатов](Untitled%201/Untitled%204.md)