# Личное

[Правила жизни](Untitled/Untitled.md)

[? Письмо матери](Untitled/Untitled%201.md)

[Инструменты руководителя](Untitled/Untitled%202.md)

[Хотелки](Untitled/Untitled%203.md)

[Текущее био](Untitled/Untitled%204.md)

[Диета от Алёны](Untitled/Untitled%205.md)

[Нютик](Untitled/Untitled%206.md)

[http://sigitova.ru/spisok-dlya-samopodderzhki-2412/](http://sigitova.ru/spisok-dlya-samopodderzhki-2412/)