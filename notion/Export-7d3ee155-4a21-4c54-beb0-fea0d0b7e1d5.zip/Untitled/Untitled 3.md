# Хотелки

BMW i8 Roadster — 13250000

[https://www.bmw.ru/myconfig/y7f4w5y1](https://www.bmw.ru/myconfig/y7f4w5y1)

Беспроводная клавиатура "под мак" — 7000

[https://www.citilink.ru/catalog/computers_and_notebooks/periferiya/km/486647/](https://www.citilink.ru/catalog/computers_and_notebooks/periferiya/km/486647/)

RodeCasper Pro — 54000

[https://pop-music.ru/products/tsifrovaya-studiya-rode-caster-pro-888880026031/](https://pop-music.ru/products/tsifrovaya-studiya-rode-caster-pro-888880026031/)

Rode PodMic — 10000

[https://pop-music.ru/products/mikrofon-rode-podmic-888880026024/](https://pop-music.ru/products/mikrofon-rode-podmic-888880026024/)

Пантограф Rode PSA1 — 7500

[https://pop-music.ru/products/pantograf-rode-psa1-888880025473/](https://pop-music.ru/products/pantograf-rode-psa1-888880025473/)

Амортизатор АМ-50 — 3150

[https://www.muztorg.ru/product/A081568](https://www.muztorg.ru/product/A081568)

Акустический экран — 15000

[https://pop-music.ru/products/filtr-se-electronics-reflexion-filter-pro-888880013175/](https://pop-music.ru/products/filtr-se-electronics-reflexion-filter-pro-888880013175/)

Цифровой микшер — 26000

[https://www.muztorg.ru/product/A058967](https://www.muztorg.ru/product/A058967)

Струбцина — 13000

[https://www.muztorg.ru/product/A037203](https://www.muztorg.ru/product/A037203)

Shure SM7B — 32000

[https://www.muztorg.ru/product/61258](https://www.muztorg.ru/product/61258)

Shure Beta 58A — 15000

[https://www.muztorg.ru/product/18433](https://www.muztorg.ru/product/18433)

Рэковая стойка под музаппарат

[https://artist-pro.ru/tempo-rs300](https://artist-pro.ru/tempo-rs300)

Охуенный цифровой микшер

[https://www.muztorg.ru/product/A060732](https://www.muztorg.ru/product/A060732)