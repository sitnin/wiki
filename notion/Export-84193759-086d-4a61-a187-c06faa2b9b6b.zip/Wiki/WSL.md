# WSL

[~/.profile](WSL/profile.md)

[/etc/wsl.conf](WSL/etc%20wsl%20conf.md)

[/etc/mtab](WSL/etc%20mtab.md)