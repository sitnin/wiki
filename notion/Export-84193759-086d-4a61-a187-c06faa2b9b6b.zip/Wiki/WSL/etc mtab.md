# /etc/mtab

Ещё вопрос, нужно ли делать mtab (см. wsl.conf)

    C: /mnt/c drvfs rw,noatime,uid=1000,gid=1000,umask=22,fmask=11,metadata,case=off 0 0
    D: /mnt/d drvfs rw,noatime,uid=1000,gid=1000,umask=22,fmask=11,metadata,case=off 0 0
    E: /mnt/e drvfs rw,noatime,uid=1000,gid=1000,umask=22,fmask=11,metadata,case=off 0 0