# /etc/wsl.conf

[automount]
    enabled=true
    mountFsTab=false
    root=/mnt/
    options=uid=1000,gid=1000,case=off,umask=22,fmask=11,metadata