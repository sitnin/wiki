# ~/.profile

[https://www.turek.dev/post/fix-wsl-file-permissions/](https://www.turek.dev/post/fix-wsl-file-permissions/)

    # Note: Bash on Windows does not currently apply umask properly.
    if [ "$(umask)" = "0000" ]; then
      umask 0022
    fi