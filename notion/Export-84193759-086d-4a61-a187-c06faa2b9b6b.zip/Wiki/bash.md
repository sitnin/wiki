# bash

# Полезное для bash

## Переименовать все файлы по цифрам

    $ for i in {10..27}; do mv "Фото ${i}.jpg" "${i}.jpg"; done

## Что-то сделать со всеми файлами вообще

    $ for i in *; do echo ${i}; done

## удалить нафиг найденное

    $ find . -iname *.pyc xargs rm