# docker

# Полезное для Docker’а

## Запустить инстанс PostgreSQL

    docker run -d
        --name postgres10
        --restart unless-stopped
        -e POSTGRES_PASSWORD=gfhjkm
        -p 127.0.0.1:5432:5432
        -v /root/Docker/postgres10:/var/lib/postgresql/data
        postgres:10.3

    docker run -d
        --name mariadb
        --restart unless-stopped
        -e MYSQL_ROOT_PASSWORD=gfhjkm
        -e MYSQL_ALLOW_EMPTY_PASSWORD=false
        -p 127.0.0.1:3306:3306
        -v root/docker/mariadb:/var/lib/mysql
        mariadb

    docker exec mariadb sh -c
        'exec mysqldump --all-databases -uroot -pNy2XVuyjhnQyWhUf9PzDPN'
        > mariadb_all.sql

    docker run -d
        --name mongo
        --restart unless-stopped
        -p 127.0.0.1:27017:27017
        -v /Users/gregor/Docker/mongodb:/data/db
        mongo:3.6

    docker run -d
        --name mongo-express
        --restart unless-stopped
        --link mongo
        -p 127.0.0.1:27081:8081
        mongo-express

    docker run -d
        --name redis
        --restart unless-stopped
        -p 127.0.0.1:6379:6379
        -v /Users/sitnin/Docker/redis:/data
        -d redis:3.2

    docker run -d
        --name mailhog
        --restart unless-stopped
        -p 127.0.0.1:1025:1025
        -p 127.0.0.1:8025:8025
        mailhog/mailhog

    docker run -d
        --name rabbitmq
        --restart unless-stopped
        -p 127.0.0.1:5671-5672:5671-5672
        -p 127.0.0.1:15671:15671
        -p 127.0.0.1:25672:25672
        -p 127.0.0.1:4369:4369
        -p 127.0.0.1:15672:15672
        rabbitmq:3-management

    docker run -d
        --name nats
        --restart unless-stopped
        -p 127.0.0.1:4222:4222
        -p 127.0.0.1:6222:6222
        -p 127.0.0.1:8222:8222
        nats