# links

## Полезные сервисы

- https://ethereal.email — эфермерные почтовые ящики для тестирования nodemailer