# postgres

# Полезности для PostgreSQL

## Установка свежей версии из пакетов (ubuntu)

https://www.postgresql.org/download/linux/ubuntu/

/etc/apt/sources.list.d/pgdg.list

    deb http://apt.postgresql.org/pub/repos/apt/ xenial-pgdg main

    # wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
    # apt-get update

## Поменять пароль пользователя

    # su - postgres
    $ psql
    > alter user postgres password 'apassword';
    > flush priveleges;

## Присоединиться к базе

    $ psql -h 127.0.0.1 -U postgres postgres

## Создать роль и базу

    create role ROLENAME with login encrypted password 'PASSWORD';
    create database SOMEDBNAME with owner=ROLENAME encoding='UTF8';