# ssh

Пробросить порт с удалённого сервера (5432) на локальную машину (9000)

[https://blog.trackets.com/2014/05/17/ssh-tunnel-local-and-remote-port-forwarding-explained-with-examples.html](https://blog.trackets.com/2014/05/17/ssh-tunnel-local-and-remote-port-forwarding-explained-with-examples.html)

    ssh -L 9000:localhost:5432 [root@fst-03.sitnin.com](mailto:root@fst-03.sitnin.com) -N