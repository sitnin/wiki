# ufw

# UFW на Ubuntu

https://www.digitalocean.com/community/tutorials/how-to-set-up-a-firewall-with-ufw-on-ubuntu-16-04

## Проверить правила с номерами

    # ufw status numbered