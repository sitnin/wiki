# Nothing Is Over. Sunrise avenue

Don’t turn away
There’s still time
A tiny moment

Don’t let go today
We can still shine
We are not broken

Scares to see that we are
[A] step a way
The one to take us
one way wrong way

Say nothing is over
Though everything’s crazy
Be brave and trust me
It’s not a game over

We gotta try harder
You gotta stay with me
There’s nothing we can’t reach
Cause nothing is over

I won’t turn away
Cause I can’t hide
The pain would find me

Don’t send me away
I’m on your side
That’s where I want to be

It seems to me that we are
[Just] like the rest
We could use a word of guidance

I hate to see that we are
One step away
The one to take us
One way wrong way

Say nothing is over
Though everything’s crazy
Be brave and trust me
It’s not a game over

We gotta try harder
You gotta stay with me
There’s nothing we can’t reach
Cause nothing is over

Say nothing is over
Though everything’s crazy
Be brave and trust me
It’s not a game over

We gotta try harder
You gotta stay with me
There’s nothing we can’t reach
Cause nothing is over

Nothing is over